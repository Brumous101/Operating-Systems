//console.h
#pragma once
void serial_outchar(char c);
//Not in notes but I added this here:
void console_putc(char c);